import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
class SudokuGenerator {
    private SudokuGrid grid;
    private final Map<String, SudokuCell> cellsMap;

    public SudokuGenerator() {
        this.cellsMap = new HashMap<>();
    }

    public SudokuGrid generate() throws Exception {
        while (true) {
            grid = new SudokuGrid();
            initializeCellsMap();
            try {
                collapseWaveFunction();
                if (grid.countInvalidBoxes() == 0) {
                    return grid;
                }
            } catch (InvalidGridException e) {
                continue;
            }
        }
    }
    private void initializeCellsMap() {
        cellsMap.clear();
        for (int r = 0; r < 9; r++) {
            for (int c = 0; c < 9; c++) {
                String key = r + "," + c;
                cellsMap.put(key, grid.grid[r][c]);
            }
        }
    }
    private void collapseWaveFunction() throws InvalidGridException {
        while (true) {
            Optional<SudokuCell> cellOpt = cellsMap.values().stream()
                    .filter(cell -> !cell.isSet())
                    .min(Comparator.comparingInt(cell -> cell.getPossibilities().size()));

            if (!cellOpt.isPresent()) {
                break;
            }

            SudokuCell cell = cellOpt.get();
            Set<Integer> possibilities = cell.getPossibilities();

            if (possibilities.isEmpty()) {
                throw new InvalidGridException("A cell has no possible values.");
            }

            // Randomly select one possibility
            int selectedValue = getRandomElement(possibilities);
            cell.setValue(selectedValue);
            propagateConstraints(cell, selectedValue);
        }
    }
    private void propagateConstraints(SudokuCell cell, int value) throws InvalidGridException {
        int row = cell.getRow();
        int col = cell.getCol();

        // Remove from same row
        for (int c = 0; c < 9; c++) {
            if (c == col) continue;
            SudokuCell related = grid.grid[row][c];
            if (!related.isSet() && related.getPossibilities().remove(value)) {
                if (related.getPossibilities().isEmpty()) {
                    throw new InvalidGridException("A cell has no possible values after propagation.");
                }
            }
        }

        // Remove from same column
        for (int r = 0; r < 9; r++) {
            if (r == row) continue;
            SudokuCell related = grid.grid[r][col];
            if (!related.isSet() && related.getPossibilities().remove(value)) {
                if (related.getPossibilities().isEmpty()) {
                    throw new InvalidGridException("A cell has no possible values after propagation.");
                }
            }
        }

        // Remove from same block
        int startRow = (row / 3) * 3;
        int startCol = (col / 3) * 3;
        for (int r = startRow; r < startRow + 3; r++) {
            for (int c = startCol; c < startCol + 3; c++) {
                if (r == row && c == col) continue;
                SudokuCell related = grid.grid[r][c];
                if (!related.isSet() && related.getPossibilities().remove(value)) {
                    if (related.getPossibilities().isEmpty()) {
                        throw new InvalidGridException("A cell has no possible values after propagation.");
                    }
                }
            }
        }
    }
    private int getRandomElement(Set<Integer> set) {
        int size = set.size();
        int item = ThreadLocalRandom.current().nextInt(size);
        int i = 0;
        for (int val : set) {
            if (i == item)
                return val;
            i++;
        }
        throw new NoSuchElementException();
    }
    static class InvalidGridException extends Exception {
        public InvalidGridException(String message) {
            super(message);
        }
    }
}