import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) {
        SudokuGenerator generator = new SudokuGenerator();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Sudoku Generator using Wave Function Collapse Algorithm");
        System.out.println("Press Enter to generate a new Sudoku grid. Type 'exit' to quit.");
        while (true) {
            System.out.print("Press Enter to generate: ");
            try {
                String input = reader.readLine();
                if (input == null || input.trim().equalsIgnoreCase("exit")) {
                    System.out.println("Exiting.");
                    break;
                }
                SudokuGrid grid = generator.generate();
                grid.display();
                long invalidBoxes = grid.countInvalidBoxes();
                System.out.println("Number of invalid boxes: " + invalidBoxes);
            } catch (Exception e) {
                System.out.println("An error occurred: " + e.getMessage());
            }
        }

    }
}