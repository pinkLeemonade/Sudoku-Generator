import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;
class SudokuGrid {
    public final SudokuCell[][] grid;

    public SudokuGrid() {
        grid = new SudokuCell[9][9];
        for (int r = 0; r < 9; r++) {
            for (int c = 0; c < 9; c++) {
                grid[r][c] = new SudokuCell(r, c);
            }
        }
    }

    public void setValue(int row, int col, int value) {
        grid[row][col].setValue(value);
    }

    public Integer getValue(int row, int col) {
        return grid[row][col].getValue();
    }

    public void clearValue(int row, int col) {
        grid[row][col].clearValue();
    }
    public ValidationResult isValid(int row, int col, int value) {
        boolean rowConflict = false, colConflict = false, blockConflict = false;

        // Check row
        for (int c = 0; c < 9; c++) {
            if (c == col) continue;
            Integer cellValue = grid[row][c].getValue();
            if (cellValue != null && cellValue == value) {
                rowConflict = true;
                break;
            }
        }

        // Check column
        for (int r = 0; r < 9; r++) {
            if (r == row) continue;
            Integer cellValue = grid[r][col].getValue();
            if (cellValue != null && cellValue == value) {
                colConflict = true;
                break;
            }
        }

        // Check block
        int startRow = (row / 3) * 3;
        int startCol = (col / 3) * 3;
        for (int r = startRow; r < startRow + 3; r++) {
            for (int c = startCol; c < startCol + 3; c++) {
                if (r == row && c == col) continue;
                Integer cellValue = grid[r][c].getValue();
                if (cellValue != null && cellValue == value) {
                    blockConflict = true;
                    break;
                }
            }
        }

        return new ValidationResult(rowConflict, colConflict, blockConflict);
    }
    public long countInvalidBoxes() {
        return IntStream.range(0, 9).boxed()
                .flatMap(r -> IntStream.range(0, 9).mapToObj(c -> new AbstractMap.SimpleEntry<>(r, c)))
                .filter(entry -> {
                    int r = entry.getKey();
                    int c = entry.getValue();
                    Integer val = grid[r][c].getValue();
                    if (val == null) return false;
                    ValidationResult vr = isValid(r, c, val);
                    // If any conflict exists, count as invalid
                    return vr.hasConflict();
                })
                .count();
    }
    public void display() {
        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < 9; r++) {
            if (r % 3 == 0 && r != 0) {
                sb.append("------+-------+------\n");
            }
            for (int c = 0; c < 9; c++) {
                if (c % 3 == 0 && c != 0) {
                    sb.append("| ");
                }
                Integer val = grid[r][c].getValue();
                sb.append(val != null ? val : ".").append(' ');
            }
            sb.append('\n');
        }
        System.out.println(sb.toString());
    }

    static class ValidationResult {
        boolean rowConflict;
        boolean colConflict;
        boolean blockConflict;

        public ValidationResult(boolean rowConflict, boolean colConflict, boolean blockConflict) {
            this.rowConflict = rowConflict;
            this.colConflict = colConflict;
            this.blockConflict = blockConflict;
        }

        public boolean hasConflict() {
            return rowConflict || colConflict || blockConflict;
        }

        @Override
        public String toString() {
            List<String> conflicts = new ArrayList<>();
            if (rowConflict) conflicts.add("Row Conflict");
            if (colConflict) conflicts.add("Column Conflict");
            if (blockConflict) conflicts.add("Block Conflict");
            return String.join(" AND ", conflicts);
        }
    }
}
