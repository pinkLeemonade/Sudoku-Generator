import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
class SudokuCell {
    private final int row;
    private final int col;
    private final Set<Integer> possibilities;
    private Integer value;

    public SudokuCell(int row, int col) {
        this.row = row;
        this.col = col;
        this.possibilities = new HashSet<>(IntStream.rangeClosed(1, 9).boxed().collect(Collectors.toSet()));
        this.value = null;
    }

    public int getRow() { return row; }
    public int getCol() { return col; }

    public Set<Integer> getPossibilities() {
        return possibilities;
    }

    public boolean isSet() {
        return value != null;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
        this.possibilities.clear();
        this.possibilities.add(value);
    }

    public void clearValue() {
        this.value = null;
        this.possibilities.clear();
        this.possibilities.addAll(IntStream.rangeClosed(1, 9).boxed().collect(Collectors.toSet()));
    }
}